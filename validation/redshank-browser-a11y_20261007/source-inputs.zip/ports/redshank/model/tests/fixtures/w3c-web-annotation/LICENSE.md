This repository is covered by the dual-licensing approach described in:

    http://www.w3.org/Consortium/Legal/2008/04-testsuite-copyright.html
